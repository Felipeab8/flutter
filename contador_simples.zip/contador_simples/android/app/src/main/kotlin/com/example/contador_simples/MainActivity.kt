package com.example.contador_simples

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
